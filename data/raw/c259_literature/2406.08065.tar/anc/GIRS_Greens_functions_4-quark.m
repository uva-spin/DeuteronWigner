Print[" This Mathematica file is supplemental to the manuscript:
   'Gauge-invariant renormalization of four-quark operators in lattice QCD'
   (authors: M. Constantinou, M. Costa, H. Herodotou, H. Panagopoulos,
             G.Spanoudes)

   The file contains perturbative results (up to one loop) relevant to the
   renormalization and mixing of the 4-quark operators with DeltaF=2 in QCD.
   In particular, it includes:

 1. The MSbar-renormalized two-point Green’s functions (involving products
    of two four-quark operators) and three-point Green’s functions
    (involving products of one 4-quark and two bilinear operators) for the
    parity-conserving (Q_i^{S=+-1}) and  parity-violating (calQ_i^{S=+-1})
    4-quark operators (i=1,...,5) [cf. Eqs. (8,12-13)]:

      (a) GF2ptMSbar[Qi, Qj, plus/minus] =
                 <Q_i^{S=+-1}(x) [Q_j^{S=+-1}(y)]^dagger>,

          GF2ptMSbar[calQi, calQj, plus/minus] =
                 <calQ_i^{S=+-1}(x) [calQ_j^{S=+-1}(y)]^dagger>,

          where i,j = 1,2,3,4,5.

          E.g., GF2ptMSbar[Q1,Q4,plus]
	        GF2ptMSbar[calQ2,calQ3,minus]  

      (b) GF3ptMSbar[OGamma, Qi, OGamma, plus/minus] =
                 <O_Gamma(x) Q_i^{S=+-1}(y) O_Gamma(w)>,

          where i = 1,2,3,4,5 and possible values of OGamma are:
	  S, P, V, A, T
          (scalar, pseudoscalar, vector, axial vector, tensor) 
 
          GF3ptMSbar[OGamma, calQi, OGamma', plus/minus] =
                 <O_Gamma(x) calQ_i^{S=+-1}(y) O_Gamma'(w)>,

          where i = 1,2,3,4,5.
          OGamma, OGamma' differ by gamma_5; thus, possible values of
	  (OGamma,OGamma') are:
	  (S,P), (V,A), (T,T')
          [(scalar, pseudoscalar), (vector, axial vector),
	   (tensor, tensor 'prime')] (see Eq. (3)).

	   E.g., GF3ptMSbar[V,Q1,V,minus]
	         GF3ptMSbar[S,calQ2,P,minus]
 
    The expressions depend on the 4-vector scales z=(x-y), z'=(y-w).
    Depending on the bilinear operators used, the three-point functions
    depend on the Lorentz indices nu[1] for V, A, and nu[1],nu[2] for T.
    Also, the expressions depend on flavor structures (see Eqs. (32-33)
    for the convention of all flavor indices). 
 
 2. The integrated (over timeslices) MSbar-renormalized two-point and
    three-point Green’s functions [cf. Eqs. (14-15)]:

      (a) GF2ptMSbarInt[Qi, Qj, plus/minus] =
          int d^3 vec{z} GF2ptMSbar[Qi, Qj, plus/minus](vec{z},t),

          GF2ptMSbarInt[calQi, calQj, plus/minus] =
          int d^3 vec{z} GF2ptMSbar[calQi, calQj, plus/minus](vec{z},t).

	  E.g., GF2ptMSbarInt[Q1,Q4,plus]
	        GF2ptMSbarInt[calQ2,calQ3,minus]  
		
      (b) GF3ptMSbarInt[OGamma, Qi, OGamma, plus/minus] =
      	  int d^3 vec{z} d^3 vec{z'}
	  GF3ptMSbar[OGamma, Qi, OGamma, plus/minus]((vec{z},t),(vec{z'},t')),

          GF3ptMSbarInt[OGamma, calQi, OGamma', plus/minus] =
      	  int d^3 vec{z} d^3 vec{z'}
        GF3ptMSbar[OGamma,calQi,OGamma',plus/minus]((vec{z},t),(vec{z'},t')).

	   E.g., GF3ptMSbarInt[V,Q1,V,minus]
	         GF3ptMSbarInt[S,calQ2,P,minus]

    See point 1. for the notation.

    Results for the Green's functions involving V, A, T are given for spatial
    components (cf. Section IV.3). 

    The expressions depend on the time scale t (In the three-point functions,
    we set t'=t).  
  "]

Print[" Notation:

   'Log[x]' is the natural logarithm of x (logarithm to base e),

   'gsqoverpisq16' stands for gMSbar^2/(16 Pi^2), where gMSbar is the
         MSbar-renormalized coupling constant,

   'Nc' is the number of colors,

   'Nf' is the number of quark flavors,

   'Cf' is the Casimir operator in the fundamental representation:
        Cf = (Nc^2 - 1)/(2 Nc),

   'f[i], fp[i], fpp[i]' are flavor indices,

   'delf[..., ...]' is Kronecker's delta for flavor indices,

   'zsq' is the square of the distance between x and y: z^2 = (x-y)^2,

   'zpsq' is the square of the distance between y and w: zp^2 = (y-w)^2,
   
   'zpluszpsq' is the square of the distance between x and w:
    (z+zp)^2 = (x-w)^2,

   'mubarsq' is the square of the MSbar renormalization scale mubar,

   'tsq' is the time separation between the temporal components of (x and y)
    and (y and w): tsq = (x_4 - y_4)^2 = (y_4 - w_4)^2,

    'z[nu[i]], zp[nu[i]], zpluszp[nu[i]]' are the nu[i] components of the
    4-vectors (x-y), (y-w), (x-w), respectively.
    "]


GF2ptMSbar[Q1, Q1, minus] = 
    (4*(-1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + gsqoverpisq16*(1 + Nc)*
        (-6 + 12*EulerGamma + 7*Nc - 12*Log[2]) + 6*gsqoverpisq16*(1 + Nc)*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q1, plus] = 
    (4*(1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + gsqoverpisq16*(-1 + Nc)*
        (6 - 12*EulerGamma + 7*Nc + 12*Log[2]) - 6*gsqoverpisq16*(-1 + Nc)*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q2, minus] = (-16*gsqoverpisq16*(-1 + Nc)^2*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q2, plus] = (-32*Cf*gsqoverpisq16*Nc*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q3, minus] = (-16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q3, plus] = (16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q4, minus] = (-16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q4, plus] = (16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q5, minus] = (-96*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q1, Q5, plus] = (96*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q1, minus] = (-16*gsqoverpisq16*(-1 + Nc)^2*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q1, plus] = (-32*Cf*gsqoverpisq16*Nc*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q2, minus] = (4*(Nc^2 + 2*Cf*gsqoverpisq16*Nc*(-4 + 7*Nc))*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q2, plus] = (4*(Nc^2 + 2*Cf*gsqoverpisq16*Nc*(4 + 7*Nc))*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q3, minus] = (2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 24*Cf*gsqoverpisq16*Nc*
        (1 + EulerGamma - Log[2]) + 12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/
     (Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q3, plus] = (-2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 24*Cf*gsqoverpisq16*Nc*
        (1 + EulerGamma - Log[2]) + 12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/
     (Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q4, minus] = (-32*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q4, plus] = (32*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q2, Q5, minus] = 0
 
GF2ptMSbar[Q2, Q5, plus] = 0
 
GF2ptMSbar[Q3, Q1, minus] = (-16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q1, plus] = (16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q2, minus] = (2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 24*Cf*gsqoverpisq16*Nc*
        (1 + EulerGamma - Log[2]) + 12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/
     (Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q2, plus] = (-2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 24*Cf*gsqoverpisq16*Nc*
        (1 + EulerGamma - Log[2]) + 12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/
     (Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q3, minus] = ((delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc^2 + 4*Cf*gsqoverpisq16*Nc*
        (-2 + Nc*(5 + 6*EulerGamma - 6*Log[2])) + 12*Cf*gsqoverpisq16*Nc^2*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q3, plus] = ((delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc^2 + 4*Cf*gsqoverpisq16*Nc*
        (2 + Nc*(5 + 6*EulerGamma - 6*Log[2])) + 12*Cf*gsqoverpisq16*Nc^2*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q4, minus] = (-8*Cf*gsqoverpisq16*Nc*(1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q4, plus] = (-8*Cf*gsqoverpisq16*Nc*(-1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q5, minus] = (48*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q3, Q5, plus] = (-48*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q1, minus] = (-16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q1, plus] = (16*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q2, minus] = (-32*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q2, plus] = (32*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q3, minus] = (-8*Cf*gsqoverpisq16*Nc*(1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q3, plus] = (-8*Cf*gsqoverpisq16*Nc*(-1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q4, minus] = ((delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*
      (Nc + 2*(Nc^2 + 2*Cf*gsqoverpisq16*Nc*(9 + 6*EulerGamma*(3 + 2*Nc) - 
           18*Log[2] - 2*Nc*(-5 + 6*Log[2]))) + 12*Cf*gsqoverpisq16*Nc*
        (3 + 2*Nc)*Log[mubarsq*zsq]))/(2*Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q4, plus] = ((delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc*(-1 + 2*Nc) + 4*Cf*gsqoverpisq16*Nc*
        (-9 + 6*EulerGamma*(-3 + 2*Nc) + 18*Log[2] - 2*Nc*(-5 + 6*Log[2])) + 
       12*Cf*gsqoverpisq16*Nc*(-3 + 2*Nc)*Log[mubarsq*zsq]))/(2*Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q5, minus] = 
    (-3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 2*EulerGamma - 2*Log[2]) + 4*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q4, Q5, plus] = (3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 2*EulerGamma - 2*Log[2]) + 4*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q1, minus] = (-96*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q1, plus] = (96*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q2, minus] = 0
 
GF2ptMSbar[Q5, Q2, plus] = 0
 
GF2ptMSbar[Q5, Q3, minus] = (48*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q3, plus] = (-48*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q4, minus] = 
    (-3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 2*EulerGamma - 2*Log[2]) + 4*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q4, plus] = (3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 2*EulerGamma - 2*Log[2]) + 4*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q5, minus] = 
    (-6*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc - 2*Nc^2 + 4*Cf*gsqoverpisq16*Nc*
        (1 + 2*EulerGamma*(-7 + 2*Nc) + 14*Log[2] - 2*Nc*(3 + 2*Log[2])) + 
       4*Cf*gsqoverpisq16*Nc*(-7 + 2*Nc)*Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[Q5, Q5, plus] = (-6*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(-(Nc*(1 + 2*Nc)) + 4*Cf*gsqoverpisq16*Nc*
        (-1 + 2*EulerGamma*(7 + 2*Nc) - 14*Log[2] - 2*Nc*(3 + 2*Log[2])) + 
       4*Cf*gsqoverpisq16*Nc*(7 + 2*Nc)*Log[mubarsq*zsq]))/(Pi^8*zsq^6)

GF2ptMSbar[calQ1, calQ1, minus] = 
    (4*(-1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + gsqoverpisq16*(1 + Nc)*
        (-6 + 12*EulerGamma + 7*Nc - 12*Log[2]) + 6*gsqoverpisq16*(1 + Nc)*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ1, calQ1, plus] = 
    (4*(1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + gsqoverpisq16*(-1 + Nc)*
        (6 - 12*EulerGamma + 7*Nc + 12*Log[2]) - 6*gsqoverpisq16*(-1 + Nc)*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ1, calQ2, minus] = 0
 
GF2ptMSbar[calQ1, calQ2, plus] = 0
 
GF2ptMSbar[calQ1, calQ3, minus] = 0
 
GF2ptMSbar[calQ1, calQ3, plus] = 0
 
GF2ptMSbar[calQ1, calQ4, minus] = 0
 
GF2ptMSbar[calQ1, calQ4, plus] = 0
 
GF2ptMSbar[calQ1, calQ5, minus] = 0
 
GF2ptMSbar[calQ1, calQ5, plus] = 0
 
GF2ptMSbar[calQ2, calQ1, minus] = 0
 
GF2ptMSbar[calQ2, calQ1, plus] = 0
 
GF2ptMSbar[calQ2, calQ2, minus] = (-4*Nc*(Nc + 14*Cf*gsqoverpisq16*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ2, calQ2, plus] = (-4*Nc*(Nc + 14*Cf*gsqoverpisq16*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ2, calQ3, minus] = 
    (-2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 24*Cf*gsqoverpisq16*Nc*
        (1 + EulerGamma - Log[2]) + 12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/
     (Pi^8*zsq^6)
 
GF2ptMSbar[calQ2, calQ3, plus] = 
    (2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]])*
      (Nc + 24*Cf*gsqoverpisq16*Nc*(1 + EulerGamma - Log[2]) + 
       12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ2, calQ4, minus] = 0
 
GF2ptMSbar[calQ2, calQ4, plus] = 0
 
GF2ptMSbar[calQ2, calQ5, minus] = 0
 
GF2ptMSbar[calQ2, calQ5, plus] = 0
 
GF2ptMSbar[calQ3, calQ1, minus] = 0
 
GF2ptMSbar[calQ3, calQ1, plus] = 0
 
GF2ptMSbar[calQ3, calQ2, minus] = 
    (-2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 24*Cf*gsqoverpisq16*Nc*
        (1 + EulerGamma - Log[2]) + 12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/
     (Pi^8*zsq^6)
 
GF2ptMSbar[calQ3, calQ2, plus] = 
    (2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]])*
      (Nc + 24*Cf*gsqoverpisq16*Nc*(1 + EulerGamma - Log[2]) + 
       12*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ3, calQ3, minus] = 
    -((Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
         (5 + 6*EulerGamma - 6*Log[2]) + 12*Cf*gsqoverpisq16*Nc*
         Log[mubarsq*zsq]))/(Pi^8*zsq^6))
 
GF2ptMSbar[calQ3, calQ3, plus] = 
    -((Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
         (5 + 6*EulerGamma - 6*Log[2]) + 12*Cf*gsqoverpisq16*Nc*
         Log[mubarsq*zsq]))/(Pi^8*zsq^6))
 
GF2ptMSbar[calQ3, calQ4, minus] = 0
 
GF2ptMSbar[calQ3, calQ4, plus] = 0
 
GF2ptMSbar[calQ3, calQ5, minus] = 0
 
GF2ptMSbar[calQ3, calQ5, plus] = 0
 
GF2ptMSbar[calQ4, calQ1, minus] = 0
 
GF2ptMSbar[calQ4, calQ1, plus] = 0
 
GF2ptMSbar[calQ4, calQ2, minus] = 0
 
GF2ptMSbar[calQ4, calQ2, plus] = 0
 
GF2ptMSbar[calQ4, calQ3, minus] = 0
 
GF2ptMSbar[calQ4, calQ3, plus] = 0
 
GF2ptMSbar[calQ4, calQ4, minus] = 
    ((delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]])*
      (Nc + 2*(Nc^2 + 2*Cf*gsqoverpisq16*Nc*(9 + 6*EulerGamma*(3 + 2*Nc) - 
           18*Log[2] - 2*Nc*(-5 + 6*Log[2]))) + 12*Cf*gsqoverpisq16*Nc*
        (3 + 2*Nc)*Log[mubarsq*zsq]))/(2*Pi^8*zsq^6)
 
GF2ptMSbar[calQ4, calQ4, plus] = 
    ((delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]])*
      (Nc*(-1 + 2*Nc) + 4*Cf*gsqoverpisq16*Nc*
        (-9 + 6*EulerGamma*(-3 + 2*Nc) + 18*Log[2] - 2*Nc*(-5 + 6*Log[2])) + 
       12*Cf*gsqoverpisq16*Nc*(-3 + 2*Nc)*Log[mubarsq*zsq]))/(2*Pi^8*zsq^6)
 
GF2ptMSbar[calQ4, calQ5, minus] = 
    (-3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 2*EulerGamma - 2*Log[2]) + 4*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ4, calQ5, plus] = 
    (3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]])*
      (Nc + 4*Cf*gsqoverpisq16*Nc*(5 + 2*EulerGamma - 2*Log[2]) + 
       4*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ5, calQ1, minus] = 0
 
GF2ptMSbar[calQ5, calQ1, plus] = 0
 
GF2ptMSbar[calQ5, calQ2, minus] = 0
 
GF2ptMSbar[calQ5, calQ2, plus] = 0
 
GF2ptMSbar[calQ5, calQ3, minus] = 0
 
GF2ptMSbar[calQ5, calQ3, plus] = 0
 
GF2ptMSbar[calQ5, calQ4, minus] = 
    (-3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 2*EulerGamma - 2*Log[2]) + 4*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ5, calQ4, plus] = 
    (3*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]])*
      (Nc + 4*Cf*gsqoverpisq16*Nc*(5 + 2*EulerGamma - 2*Log[2]) + 
       4*Cf*gsqoverpisq16*Nc*Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ5, calQ5, minus] = 
    (-6*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(Nc - 2*Nc^2 + 4*Cf*gsqoverpisq16*Nc*
        (1 + 2*EulerGamma*(-7 + 2*Nc) + 14*Log[2] - 2*Nc*(3 + 2*Log[2])) + 
       4*Cf*gsqoverpisq16*Nc*(-7 + 2*Nc)*Log[mubarsq*zsq]))/(Pi^8*zsq^6)
 
GF2ptMSbar[calQ5, calQ5, plus] = 
    (-6*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(-(Nc*(1 + 2*Nc)) + 4*Cf*gsqoverpisq16*Nc*
        (-1 + 2*EulerGamma*(7 + 2*Nc) - 14*Log[2] - 2*Nc*(3 + 2*Log[2])) + 
       4*Cf*gsqoverpisq16*Nc*(7 + 2*Nc)*Log[mubarsq*zsq]))/(Pi^8*zsq^6)

GF3ptMSbar[S, Q1, S, minus] = (-8*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q1, S, plus] = (8*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q2, S, minus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 6*Cf*gsqoverpisq16*Nc*
        (1 + 4*EulerGamma - 4*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
        (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
     (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q2, S, plus] = 
    -(((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc + 6*Cf*gsqoverpisq16*Nc*
         (1 + 4*EulerGamma - 4*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
         (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
      (Pi^8*zsq^3*zpsq^3))
 
GF3ptMSbar[S, Q3, S, minus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc^2 + 4*Cf*gsqoverpisq16*Nc*
        (-2 + Nc + 6*EulerGamma*Nc - 6*Nc*Log[2]) + 6*Cf*gsqoverpisq16*Nc^2*
        (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
     (2*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q3, S, plus] = ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc^2 + 4*Cf*gsqoverpisq16*Nc*
        (2 + Nc + 6*EulerGamma*Nc - 6*Nc*Log[2]) + 6*Cf*gsqoverpisq16*Nc^2*
        (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
     (2*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q4, S, minus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*
      (Nc + 2*(Nc^2 + 2*Cf*gsqoverpisq16*Nc*(3 + 2*Nc + 12*EulerGamma*
            (1 + Nc) - 12*(1 + Nc)*Log[2])) + 6*Cf*gsqoverpisq16*Nc*
        (-2*Log[mubarsq*zpluszpsq] + (3 + 2*Nc)*(Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))))/(4*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q4, S, plus] = ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc*(-1 + 2*Nc) + 4*Cf*gsqoverpisq16*Nc*
        (-3 + 12*EulerGamma*(-1 + Nc) + Nc*(2 - 12*Log[2]) + 12*Log[2]) + 
       6*Cf*gsqoverpisq16*Nc*(2*Log[mubarsq*zpluszpsq] + 
         (-3 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq]))))/
     (4*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q5, S, minus] = 
    (-3*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (1 + 4*EulerGamma - 4*Log[2]) + 2*Cf*gsqoverpisq16*Nc*
        (2*Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
         Log[mubarsq*zpsq])))/(2*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, Q5, S, plus] = 
    (3*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (1 + 4*EulerGamma - 4*Log[2]) + 2*Cf*gsqoverpisq16*Nc*
        (2*Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
         Log[mubarsq*zpsq])))/(2*Pi^8*zsq^3*zpsq^3)

GF3ptMSbar[P, Q1, P, minus] = 0
 
GF3ptMSbar[P, Q1, P, plus] = 0
 
GF3ptMSbar[P, Q2, P, minus] = 
    -(((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc + 2*Cf*gsqoverpisq16*Nc*
         (19 + 12*EulerGamma - 12*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
         (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
      (Pi^8*zsq^3*zpsq^3))
 
GF3ptMSbar[P, Q2, P, plus] = ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 2*Cf*gsqoverpisq16*Nc*
        (19 + 12*EulerGamma - 12*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
        (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
     (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[P, Q3, P, minus] = 
    -1/2*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc + 12*Cf*gsqoverpisq16*Nc*
         (3 + 2*EulerGamma - 2*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
         (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
      (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[P, Q3, P, plus] = 
    -1/2*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc + 12*Cf*gsqoverpisq16*Nc*
         (3 + 2*EulerGamma - 2*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
         (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
      (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[P, Q4, P, minus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*
      (Nc + 2*(Nc^2 + 2*Cf*gsqoverpisq16*Nc*(11 + 18*Nc + 
           12*EulerGamma*(1 + Nc) - 12*(1 + Nc)*Log[2])) + 
       6*Cf*gsqoverpisq16*Nc*(-2*Log[mubarsq*zpluszpsq] + 
         (3 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq]))))/
     (4*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[P, Q4, P, plus] = ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc*(-1 + 2*Nc) + 4*Cf*gsqoverpisq16*Nc*
        (-11 + 12*EulerGamma*(-1 + Nc) + 12*Log[2] - 6*Nc*(-3 + 2*Log[2])) + 
       6*Cf*gsqoverpisq16*Nc*(2*Log[mubarsq*zpluszpsq] + 
         (-3 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq]))))/
     (4*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[P, Q5, P, minus] = 
    (-3*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (9 + 4*EulerGamma - 4*Log[2]) + 2*Cf*gsqoverpisq16*Nc*
        (2*Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
         Log[mubarsq*zpsq])))/(2*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[P, Q5, P, plus] = 
    (3*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (9 + 4*EulerGamma - 4*Log[2]) + 2*Cf*gsqoverpisq16*Nc*
        (2*Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
         Log[mubarsq*zpsq])))/(2*Pi^8*zsq^3*zpsq^3)

GF3ptMSbar[V, Q1, V, minus] = 
    ((1 - Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(2*zpsq*(Nc*zpluszpsq + 
         gsqoverpisq16*(1 + Nc)*(-zsq + zpluszpsq*(-2 + 6*EulerGamma + 
             3*Nc - 6*Log[2])) + 3*gsqoverpisq16*(1 + Nc)*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 - 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (Nc + gsqoverpisq16*(1 + Nc)*(-2 + 6*EulerGamma + 3*Nc - 6*Log[2]) + 
         3*gsqoverpisq16*(1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] - 
       zpluszpsq*(zsq*zpsq*(Nc + 3*gsqoverpisq16*(1 + Nc)*
            (-1 + 2*EulerGamma + Nc - 2*Log[2]) + 3*gsqoverpisq16*(1 + Nc)*
            (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
             Log[mubarsq*zpsq])) - 2*zpluszpsq*
          (Nc + gsqoverpisq16*(1 + Nc)*(-2 + 6*EulerGamma + 3*Nc - 
             6*Log[2]) + 3*gsqoverpisq16*(1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
          zp[nu[1]]^2)))/(2*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q1, V, plus] = 
    ((1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(2*zpsq*(-(Nc*zpluszpsq) - 
         gsqoverpisq16*(-1 + Nc)*(zsq + zpluszpsq*(2 - 6*EulerGamma + 
             3*Nc + 6*Log[2])) + 3*gsqoverpisq16*(-1 + Nc)*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 - 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (-Nc - gsqoverpisq16*(-1 + Nc)*(2 - 6*EulerGamma + 3*Nc + 6*Log[2]) + 
         3*gsqoverpisq16*(-1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] + 
       zpluszpsq*(zsq*zpsq*(Nc + 3*gsqoverpisq16*(-1 + Nc)*
            (1 - 2*EulerGamma + Nc + 2*Log[2]) + 3*gsqoverpisq16*(-1 + Nc)*
            (Log[mubarsq*zpluszpsq] - Log[mubarsq*zsq] - 
             Log[mubarsq*zpsq])) + 2*zpluszpsq*
          (-Nc - gsqoverpisq16*(-1 + Nc)*(2 - 6*EulerGamma + 3*Nc + 
             6*Log[2]) + 3*gsqoverpisq16*(-1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
          zp[nu[1]]^2)))/(2*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q2, V, minus] = (Nc*(Nc + 6*Cf*gsqoverpisq16*Nc)*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(2*Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q2, V, plus] = (Nc*(Nc + 6*Cf*gsqoverpisq16*Nc)*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(2*Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q3, V, minus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-2*zpsq*(Nc*zpluszpsq - 
         2*Cf*gsqoverpisq16*Nc*(zsq - 6*zpluszpsq*(1 + EulerGamma - 
             Log[2])) + 6*Cf*gsqoverpisq16*Nc*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 + 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (Nc + 12*Cf*gsqoverpisq16*Nc*(1 + EulerGamma - Log[2]) + 
         6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] + 
       zpluszpsq*(zsq*zpsq*(Nc + 2*Cf*gsqoverpisq16*Nc*
            (5 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
            (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
             Log[mubarsq*zpsq])) - 2*zpluszpsq*
          (Nc + 12*Cf*gsqoverpisq16*Nc*(1 + EulerGamma - Log[2]) + 
           6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
          zp[nu[1]]^2)))/(4*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q3, V, plus] = 
    -1/4*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-2*zpsq*(Nc*zpluszpsq - 
          2*Cf*gsqoverpisq16*Nc*(zsq - 6*zpluszpsq*(1 + EulerGamma - 
              Log[2])) + 6*Cf*gsqoverpisq16*Nc*zpluszpsq*
           (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
            Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 + 
        2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
         (Nc + 12*Cf*gsqoverpisq16*Nc*(1 + EulerGamma - Log[2]) + 
          6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
            Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
         zpluszp[nu[1]]*zp[nu[1]] + 
        zpluszpsq*(zsq*zpsq*(Nc + 2*Cf*gsqoverpisq16*Nc*
             (5 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
             (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
              Log[mubarsq*zpsq])) - 2*zpluszpsq*
           (Nc + 12*Cf*gsqoverpisq16*Nc*(1 + EulerGamma - Log[2]) + 
            6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
              Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
           zp[nu[1]]^2)))/(Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q4, V, minus] = (-3*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q4, V, plus] = (3*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q5, V, minus] = (-6*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[V, Q5, V, plus] = (6*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)

GF3ptMSbar[A, Q1, A, minus] = 
    ((-1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-2*zpsq*(Nc*zpluszpsq + 
         gsqoverpisq16*(1 + Nc)*(-zsq + zpluszpsq*(6*EulerGamma + 
             11*Nc - 2*(5 + 3*Log[2]))) - 3*gsqoverpisq16*(1 + Nc)*zpluszpsq*
          (Log[mubarsq*zpluszpsq] - Log[mubarsq*zsq] - 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 + 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (Nc + gsqoverpisq16*(1 + Nc)*(6*EulerGamma + 11*Nc - 
           2*(5 + 3*Log[2])) + 3*gsqoverpisq16*(1 + Nc)*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]*
        zp[nu[1]] + zpluszpsq*(zsq*zpsq*
          (Nc + gsqoverpisq16*(1 + Nc)*(-11 + 6*EulerGamma + 11*Nc - 
             6*Log[2]) + 3*gsqoverpisq16*(1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq])) - 
         2*zpluszpsq*(Nc + gsqoverpisq16*(1 + Nc)*(6*EulerGamma + 11*Nc - 
             2*(5 + 3*Log[2])) + 3*gsqoverpisq16*(1 + Nc)*
            (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
             Log[mubarsq*zpsq]))*zp[nu[1]]^2)))/
     (2*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q1, A, plus] = 
    ((1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(2*zpsq*(-(Nc*zpluszpsq) - 
         gsqoverpisq16*(-1 + Nc)*(zsq + zpluszpsq*(10 - 6*EulerGamma + 
             11*Nc + 6*Log[2])) + 3*gsqoverpisq16*(-1 + Nc)*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 - 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (-Nc - gsqoverpisq16*(-1 + Nc)*(10 - 6*EulerGamma + 11*Nc + 
           6*Log[2]) + 3*gsqoverpisq16*(-1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] + 
       zpluszpsq*(zsq*zpsq*(Nc + gsqoverpisq16*(-1 + Nc)*
            (11 - 6*EulerGamma + 11*Nc + 6*Log[2]) + 3*gsqoverpisq16*
            (-1 + Nc)*(Log[mubarsq*zpluszpsq] - Log[mubarsq*zsq] - 
             Log[mubarsq*zpsq])) + 2*zpluszpsq*
          (-Nc - gsqoverpisq16*(-1 + Nc)*(10 - 6*EulerGamma + 11*Nc + 
             6*Log[2]) + 3*gsqoverpisq16*(-1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
          zp[nu[1]]^2)))/(2*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q2, A, minus] = 
    -1/2*((Nc^2 + 2*Cf*gsqoverpisq16*Nc*(-4 + 11*Nc))*
       (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(zsq*zpsq - 
        2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
          zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
        2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q2, A, plus] = -1/2*((Nc^2 + 2*Cf*gsqoverpisq16*Nc*(4 + 11*Nc))*
       (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(zsq*zpsq - 
        2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
          zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
        2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q3, A, minus] = 
    -1/4*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-2*zpsq*(Nc*zpluszpsq - 
          2*Cf*gsqoverpisq16*Nc*(zsq + 2*zpluszpsq*(-7 - 3*EulerGamma + 
              3*Log[2])) + 6*Cf*gsqoverpisq16*Nc*zpluszpsq*
           (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
            Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 + 
        2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
         (Nc + 4*Cf*gsqoverpisq16*Nc*(7 + 3*EulerGamma - 3*Log[2]) + 
          6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
            Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
         zpluszp[nu[1]]*zp[nu[1]] + 
        zpluszpsq*(zsq*zpsq*(Nc + 2*Cf*gsqoverpisq16*Nc*
             (13 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
             (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
              Log[mubarsq*zpsq])) - 2*zpluszpsq*
           (Nc + 4*Cf*gsqoverpisq16*Nc*(7 + 3*EulerGamma - 3*Log[2]) + 
            6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
              Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
           zp[nu[1]]^2)))/(Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q3, A, plus] = ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-2*zpsq*(Nc*zpluszpsq - 
         2*Cf*gsqoverpisq16*Nc*(zsq + 2*zpluszpsq*(-7 - 3*EulerGamma + 
             3*Log[2])) + 6*Cf*gsqoverpisq16*Nc*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 + 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (Nc + 4*Cf*gsqoverpisq16*Nc*(7 + 3*EulerGamma - 3*Log[2]) + 
         6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] + 
       zpluszpsq*(zsq*zpsq*(Nc + 2*Cf*gsqoverpisq16*Nc*
            (13 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
            (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
             Log[mubarsq*zpsq])) - 2*zpluszpsq*
          (Nc + 4*Cf*gsqoverpisq16*Nc*(7 + 3*EulerGamma - 3*Log[2]) + 
           6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
          zp[nu[1]]^2)))/(4*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q4, A, minus] = (Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q4, A, plus] = 
    -((Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(zsq*zpsq - 
        2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
          zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
        2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4))
 
GF3ptMSbar[A, Q5, A, minus] = (-6*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[A, Q5, A, plus] = (6*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
         zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
       2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)

GF3ptMSbar[T, Q1, T, minus] = (-4*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpluszp[nu[2]]^2*(zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, Q1, T, plus] = (4*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpluszp[nu[2]]^2*(zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, Q2, T, minus] = (2*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*
      (-(delf[fp[1], f[4]]*delf[f[3], fpp[1]]) + 
       delf[fp[1], f[3]]*delf[f[4], fpp[1]])*
      (zpluszpsq - 2*zpluszp[nu[1]]^2 - 2*zpluszp[nu[2]]^2))/
     (Pi^8*zpluszpsq*zsq^3*zpsq^3)
 
GF3ptMSbar[T, Q2, T, plus] = (2*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zpluszpsq - 2*zpluszp[nu[1]]^2 - 
       2*zpluszp[nu[2]]^2))/(Pi^8*zpluszpsq*zsq^3*zpsq^3)
 
GF3ptMSbar[T, Q3, T, minus] = (2*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpluszp[nu[2]]^2*(zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, Q3, T, plus] = (-2*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zsq*zpsq - 
       2*zpluszp[nu[2]]^2*(zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, Q4, T, minus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-Nc - 16*Cf*gsqoverpisq16*Nc + 
       2*Cf*gsqoverpisq16*Nc*(2*Log[mubarsq*zpluszpsq] - 
         Log[mubarsq*zsq] - Log[mubarsq*zpsq]))*
      (zsq*zpsq - 2*zpluszp[nu[2]]^2*
        (zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (4*Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, Q4, T, plus] = 
    -1/4*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-Nc - 16*Cf*gsqoverpisq16*Nc + 
        2*Cf*gsqoverpisq16*Nc*(2*Log[mubarsq*zpluszpsq] - 
          Log[mubarsq*zsq] - Log[mubarsq*zpsq]))*
       (zsq*zpsq - 2*zpluszp[nu[2]]^2*
         (zpsq - 2*zp[nu[1]]^2) + 
        2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
         zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
         (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
           zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
         (zpsq - 2*zp[nu[2]]^2) - 2*zpluszpsq*
         (zp[nu[1]]^2 + zp[nu[2]]^2)))/
      (Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, Q5, T, minus] = 
    ((-(delf[fp[2], f[2]]*delf[f[1], fpp[2]]) + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc - 2*Nc^2 + 8*Cf*gsqoverpisq16*Nc*
        (1 + 2*EulerGamma*(-2 + Nc) - Nc*(3 + 2*Log[2]) + Log[16]) + 
       2*Cf*gsqoverpisq16*Nc*(6*Log[mubarsq*zpluszpsq] + 
         (-7 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq])))*
      (zsq*zpsq - 2*zpluszp[nu[2]]^2*
        (zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (2*Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, Q5, T, plus] = 
    -1/2*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-(Nc*(1 + 2*Nc)) + 8*Cf*gsqoverpisq16*Nc*
         (-1 + 2*EulerGamma*(2 + Nc) - 4*Log[2] - Nc*(3 + 2*Log[2])) + 
        2*Cf*gsqoverpisq16*Nc*(-6*Log[mubarsq*zpluszpsq] + 
          (7 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq])))*
       (zsq*zpsq - 2*zpluszp[nu[2]]^2*
         (zpsq - 2*zp[nu[1]]^2) + 
        2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
         zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
         (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
           zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
         (zpsq - 2*zp[nu[2]]^2) - 2*zpluszpsq*
         (zp[nu[1]]^2 + zp[nu[2]]^2)))/
      (Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[S, calQ1, P, minus] = 0
 
GF3ptMSbar[S, calQ1, P, plus] = 0
 
GF3ptMSbar[S, calQ2, P, minus] = 
    -(((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc + 2*Cf*gsqoverpisq16*Nc*
         (11 + 12*EulerGamma - 12*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
         (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
      (Pi^8*zsq^3*zpsq^3))
 
GF3ptMSbar[S, calQ2, P, plus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 2*Cf*gsqoverpisq16*Nc*
        (11 + 12*EulerGamma - 12*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
        (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
     (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, calQ3, P, minus] = 
    -1/2*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
         (5 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
         (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
      (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, calQ3, P, plus] = 
    -1/2*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
         (5 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
         (Log[mubarsq*zsq] + Log[mubarsq*zpsq])))/
      (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, calQ4, P, minus] = 
    -1/4*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*
       (Nc + 2*(Nc^2 + 2*Cf*gsqoverpisq16*Nc*(7 + 10*Nc + 12*EulerGamma*
             (1 + Nc) - 12*(1 + Nc)*Log[2])) + 6*Cf*gsqoverpisq16*Nc*
         (-2*Log[mubarsq*zpluszpsq] + (3 + 2*Nc)*(Log[mubarsq*zsq] + 
            Log[mubarsq*zpsq]))))/(Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, calQ4, P, plus] = 
    -1/4*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(Nc*(-1 + 2*Nc) + 4*Cf*gsqoverpisq16*Nc*
         (-7 + 12*EulerGamma*(-1 + Nc) + 2*Nc*(5 - 6*Log[2]) + 12*Log[2]) + 
        6*Cf*gsqoverpisq16*Nc*(2*Log[mubarsq*zpluszpsq] + 
          (-3 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq]))))/
      (Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, calQ5, P, minus] = 
    (3*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 4*EulerGamma - 4*Log[2]) + 2*Cf*gsqoverpisq16*Nc*
        (2*Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
         Log[mubarsq*zpsq])))/(2*Pi^8*zsq^3*zpsq^3)
 
GF3ptMSbar[S, calQ5, P, plus] = 
    (-3*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 4*Cf*gsqoverpisq16*Nc*
        (5 + 4*EulerGamma - 4*Log[2]) + 2*Cf*gsqoverpisq16*Nc*
        (2*Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
         Log[mubarsq*zpsq])))/(2*Pi^8*zsq^3*zpsq^3)

GF3ptMSbar[V, calQ1, A, minus] = 
    ((1 - Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(2*zpsq*(Nc*zpluszpsq + 
         gsqoverpisq16*(1 + Nc)*(-zsq + zpluszpsq*(-6 + 6*EulerGamma + 
             7*Nc - 6*Log[2])) + 3*gsqoverpisq16*(1 + Nc)*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 - 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (Nc + gsqoverpisq16*(1 + Nc)*(6*EulerGamma + 7*Nc - 6*(1 + Log[2])) + 
         3*gsqoverpisq16*(1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] - 
       zpluszpsq*(zsq*zpsq*(Nc + gsqoverpisq16*(1 + Nc)*
            (-7 + 6*EulerGamma + 7*Nc - 6*Log[2]) + 3*gsqoverpisq16*(1 + Nc)*
            (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
             Log[mubarsq*zpsq])) - 2*zpluszpsq*
          (Nc + gsqoverpisq16*(1 + Nc)*(6*EulerGamma + 7*Nc - 
             6*(1 + Log[2])) + 3*gsqoverpisq16*(1 + Nc)*
            (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
             Log[mubarsq*zpsq]))*zp[nu[1]]^2)))/
     (2*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, calQ1, A, plus] = 
    ((1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(2*zpsq*(-(Nc*zpluszpsq) - 
         gsqoverpisq16*(-1 + Nc)*(zsq + zpluszpsq*(6 - 6*EulerGamma + 
             7*Nc + 6*Log[2])) + 3*gsqoverpisq16*(-1 + Nc)*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 - 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (-Nc - gsqoverpisq16*(-1 + Nc)*(6 - 6*EulerGamma + 7*Nc + 6*Log[2]) + 
         3*gsqoverpisq16*(-1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] + 
       zpluszpsq*(zsq*zpsq*(Nc + gsqoverpisq16*(-1 + Nc)*
            (7 - 6*EulerGamma + 7*Nc + 6*Log[2]) + 3*gsqoverpisq16*(-1 + Nc)*
            (Log[mubarsq*zpluszpsq] - Log[mubarsq*zsq] - 
             Log[mubarsq*zpsq])) + 2*zpluszpsq*
          (-Nc - gsqoverpisq16*(-1 + Nc)*(6 - 6*EulerGamma + 7*Nc + 
             6*Log[2]) + 3*gsqoverpisq16*(-1 + Nc)*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
          zp[nu[1]]^2)))/(2*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, calQ2, A, minus] = (Nc*(Nc + 14*Cf*gsqoverpisq16*Nc)*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*
      (-(delf[fp[1], f[4]]*delf[f[3], fpp[1]]) + 
       delf[fp[1], f[3]]*delf[f[4], fpp[1]])*
      (zsq*zpsq - 2*zpsq*zpluszp[nu[1]]^2 + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[1]]*
        zp[nu[1]] - 2*zpluszpsq*zp[nu[1]]^2))/
     (2*Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[V, calQ2, A, plus] = -1/2*(Nc*(Nc + 14*Cf*gsqoverpisq16*Nc)*
       (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(zsq*zpsq - 
        2*zpsq*zpluszp[nu[1]]^2 + 2*(zpluszpsq - zsq + 
          zpsq)*zpluszp[nu[1]]*zp[nu[1]] - 
        2*zpluszpsq*zp[nu[1]]^2))/(Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[V, calQ3, A, minus] = 
    -1/4*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-2*zpsq*(Nc*zpluszpsq - 
          2*Cf*gsqoverpisq16*Nc*(zsq + 2*zpluszpsq*(-5 - 3*EulerGamma + 
              3*Log[2])) + 6*Cf*gsqoverpisq16*Nc*zpluszpsq*
           (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
            Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 + 
        2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
         (Nc + 4*Cf*gsqoverpisq16*Nc*(5 + 3*EulerGamma - 3*Log[2]) + 
          6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
            Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
         zpluszp[nu[1]]*zp[nu[1]] + 
        zpluszpsq*(zsq*zpsq*(Nc + 2*Cf*gsqoverpisq16*Nc*
             (9 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
             (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
              Log[mubarsq*zpsq])) - 2*zpluszpsq*
           (Nc + 4*Cf*gsqoverpisq16*Nc*(5 + 3*EulerGamma - 3*Log[2]) + 
            6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
              Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
           zp[nu[1]]^2)))/(Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, calQ3, A, plus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-2*zpsq*(Nc*zpluszpsq - 
         2*Cf*gsqoverpisq16*Nc*(zsq + 2*zpluszpsq*(-5 - 3*EulerGamma + 
             3*Log[2])) + 6*Cf*gsqoverpisq16*Nc*zpluszpsq*
          (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
           Log[mubarsq*zpsq]))*zpluszp[nu[1]]^2 + 
       2*zpluszpsq*(zpluszpsq - zsq + zpsq)*
        (Nc + 4*Cf*gsqoverpisq16*Nc*(5 + 3*EulerGamma - 3*Log[2]) + 
         6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
           Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
        zpluszp[nu[1]]*zp[nu[1]] + 
       zpluszpsq*(zsq*zpsq*(Nc + 2*Cf*gsqoverpisq16*Nc*
            (9 + 6*EulerGamma - 6*Log[2]) + 6*Cf*gsqoverpisq16*Nc*
            (-Log[mubarsq*zpluszpsq] + Log[mubarsq*zsq] + 
             Log[mubarsq*zpsq])) - 2*zpluszpsq*
          (Nc + 4*Cf*gsqoverpisq16*Nc*(5 + 3*EulerGamma - 3*Log[2]) + 
           6*Cf*gsqoverpisq16*Nc*(-Log[mubarsq*zpluszpsq] + 
             Log[mubarsq*zsq] + Log[mubarsq*zpsq]))*
          zp[nu[1]]^2)))/(4*Pi^8*zpluszpsq*zsq^4*zpsq^4)
 
GF3ptMSbar[V, calQ4, A, minus] = 0
 
GF3ptMSbar[V, calQ4, A, plus] = 0
 
GF3ptMSbar[V, calQ5, A, minus] = 0
 
GF3ptMSbar[V, calQ5, A, plus] = 0
 
GF3ptMSbar[T, calQ1, Tp, minus] = 0
 
GF3ptMSbar[T, calQ1, Tp, plus] = 0
 
GF3ptMSbar[T, calQ2, Tp, minus] = (2*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zpluszpsq - 2*zpluszp[nu[1]]^2 - 
       2*zpluszp[nu[2]]^2))/(Pi^8*zpluszpsq*zsq^3*zpsq^3)
 
GF3ptMSbar[T, calQ2, Tp, plus] = (-2*Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(zpluszpsq - 2*zpluszp[nu[1]]^2 - 
       2*zpluszp[nu[2]]^2))/(Pi^8*zpluszpsq*zsq^3*zpsq^3)
 
GF3ptMSbar[T, calQ3, Tp, minus] = 0
 
GF3ptMSbar[T, calQ3, Tp, plus] = 0
 
GF3ptMSbar[T, calQ4, Tp, minus] = 
    -1/4*((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-Nc - 16*Cf*gsqoverpisq16*Nc + 
        2*Cf*gsqoverpisq16*Nc*(2*Log[mubarsq*zpluszpsq] - 
          Log[mubarsq*zsq] - Log[mubarsq*zpsq]))*
       (zsq*zpsq - 2*zpluszp[nu[2]]^2*
         (zpsq - 2*zp[nu[1]]^2) + 
        2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
         zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
         (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
           zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
         (zpsq - 2*zp[nu[2]]^2) - 2*zpluszpsq*
         (zp[nu[1]]^2 + zp[nu[2]]^2)))/
      (Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, calQ4, Tp, plus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-Nc - 16*Cf*gsqoverpisq16*Nc + 
       2*Cf*gsqoverpisq16*Nc*(2*Log[mubarsq*zpluszpsq] - 
         Log[mubarsq*zsq] - Log[mubarsq*zpsq]))*
      (zsq*zpsq - 2*zpluszp[nu[2]]^2*
        (zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (4*Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, calQ5, Tp, minus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc - 2*Nc^2 + 8*Cf*gsqoverpisq16*Nc*
        (1 + 2*EulerGamma*(-2 + Nc) - Nc*(3 + Log[4]) + Log[16]) + 
       2*Cf*gsqoverpisq16*Nc*(6*Log[mubarsq*zpluszpsq] + 
         (-7 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq])))*
      (zsq*zpsq - 2*zpluszp[nu[2]]^2*
        (zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (2*Pi^8*zsq^4*zpsq^4)
 
GF3ptMSbar[T, calQ5, Tp, plus] = 
    ((delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-(Nc*(1 + 2*Nc)) + 8*Cf*gsqoverpisq16*Nc*
        (-1 + 2*EulerGamma*(2 + Nc) - 4*Log[2] - Nc*(3 + Log[4])) + 
       2*Cf*gsqoverpisq16*Nc*(-6*Log[mubarsq*zpluszpsq] + 
         (7 + 2*Nc)*(Log[mubarsq*zsq] + Log[mubarsq*zpsq])))*
      (zsq*zpsq - 2*zpluszp[nu[2]]^2*
        (zpsq - 2*zp[nu[1]]^2) + 
       2*(zpluszpsq - zsq + zpsq)*zpluszp[nu[2]]*
        zp[nu[2]] + 2*zpluszp[nu[1]]*zp[nu[1]]*
        (zpluszpsq - zsq + zpsq - 4*zpluszp[nu[2]]*
          zp[nu[2]]) - 2*zpluszp[nu[1]]^2*
        (zpsq - 2*zp[nu[2]]^2) - 
       2*zpluszpsq*(zp[nu[1]]^2 + zp[nu[2]]^2)))/
     (2*Pi^8*zsq^4*zpsq^4)

GF2ptMSbarInt[Q1, Q1, minus] = 
    ((-1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(70*Nc + gsqoverpisq16*(1 + Nc)*
        (-869 + 840*EulerGamma + 490*Nc) + 420*gsqoverpisq16*(1 + Nc)*
        Log[mubarsq*tsq]))/(320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q1, plus] = 
    ((1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(-(gsqoverpisq16*(-869 + 840*EulerGamma - 
          490*Nc)*(-1 + Nc)) + 70*Nc - 420*gsqoverpisq16*(-1 + Nc)*
        Log[mubarsq*tsq]))/(320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q2, minus] = (-7*gsqoverpisq16*(-1 + Nc)^2*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q2, plus] = (-7*Cf*gsqoverpisq16*Nc*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q3, minus] = (-7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q3, plus] = (7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q4, minus] = (-7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q4, plus] = (7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q5, minus] = (-21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q1, Q5, plus] = (21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q1, minus] = (-7*gsqoverpisq16*(-1 + Nc)^2*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q1, plus] = (-7*Cf*gsqoverpisq16*Nc*(1 + Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q2, minus] = (7*Nc*(Nc + 2*Cf*gsqoverpisq16*(-4 + 7*Nc))*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(32*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q2, plus] = (7*Nc*(Nc + 2*Cf*gsqoverpisq16*(4 + 7*Nc))*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(32*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q3, minus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q3, plus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q4, minus] = (-7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q4, plus] = (7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q2, Q5, minus] = 0
 
GF2ptMSbarInt[Q2, Q5, plus] = 0
 
GF2ptMSbarInt[Q3, Q1, minus] = (-7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q1, plus] = (7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q2, minus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q2, plus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q3, minus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35*Nc + Cf*gsqoverpisq16*
        (-280 + 251*Nc + 840*EulerGamma*Nc) + 420*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*tsq]))/(640*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q3, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35*Nc + Cf*gsqoverpisq16*
        (280 + 251*Nc + 840*EulerGamma*Nc) + 420*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*tsq]))/(640*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q4, minus] = (-7*Cf*gsqoverpisq16*Nc*(1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(16*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q4, plus] = (-7*Cf*gsqoverpisq16*Nc*(-1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(16*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q5, minus] = (21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q3, Q5, plus] = (-21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q1, minus] = (-7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q1, plus] = (7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q2, minus] = (-7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q2, plus] = (7*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q3, minus] = (-7*Cf*gsqoverpisq16*Nc*(1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(16*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q3, plus] = (-7*Cf*gsqoverpisq16*Nc*(-1 + 2*Nc)*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(16*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q4, minus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35 + 70*Nc + Cf*gsqoverpisq16*
        (-87 + 502*Nc + 840*EulerGamma*(3 + 2*Nc)) + 420*Cf*gsqoverpisq16*
        (3 + 2*Nc)*Log[mubarsq*tsq]))/(1280*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q4, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(-35 + 70*Nc + Cf*gsqoverpisq16*
        (87 + 502*Nc + 840*EulerGamma*(-3 + 2*Nc)) + 420*Cf*gsqoverpisq16*
        (-3 + 2*Nc)*Log[mubarsq*tsq]))/(1280*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q5, minus] = 
    -1/640*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q4, Q5, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (640*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q1, minus] = (-21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q1, plus] = (21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(4*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q2, minus] = 0
 
GF2ptMSbarInt[Q5, Q2, plus] = 0
 
GF2ptMSbarInt[Q5, Q3, minus] = (21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q3, plus] = (-21*Cf*gsqoverpisq16*Nc*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(8*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q4, minus] = 
    -1/640*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q4, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (640*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q5, minus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(105 - 210*Nc + Cf*gsqoverpisq16*
         (3563 - 3418*Nc + 840*EulerGamma*(-7 + 2*Nc)) + 
        420*Cf*gsqoverpisq16*(-7 + 2*Nc)*Log[mubarsq*tsq]))/(Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[Q5, Q5, plus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(-105*(1 + 2*Nc) + Cf*gsqoverpisq16*
         (-3563 - 3418*Nc + 840*EulerGamma*(7 + 2*Nc)) + 
        420*Cf*gsqoverpisq16*(7 + 2*Nc)*Log[mubarsq*tsq]))/(Pi^6*tsq^(9/2))

GF2ptMSbarInt[calQ1, calQ1, minus] = 
    ((-1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(70*Nc + gsqoverpisq16*(1 + Nc)*
        (-869 + 840*EulerGamma + 490*Nc) + 420*gsqoverpisq16*(1 + Nc)*
        Log[mubarsq*tsq]))/(320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ1, calQ1, plus] = 
    ((1 + Nc)*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(-(gsqoverpisq16*(-869 + 840*EulerGamma - 
          490*Nc)*(-1 + Nc)) + 70*Nc - 420*gsqoverpisq16*(-1 + Nc)*
        Log[mubarsq*tsq]))/(320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ1, calQ2, minus] = 0
 
GF2ptMSbarInt[calQ1, calQ2, plus] = 0
 
GF2ptMSbarInt[calQ1, calQ3, minus] = 0
 
GF2ptMSbarInt[calQ1, calQ3, plus] = 0
 
GF2ptMSbarInt[calQ1, calQ4, minus] = 0
 
GF2ptMSbarInt[calQ1, calQ4, plus] = 0
 
GF2ptMSbarInt[calQ1, calQ5, minus] = 0
 
GF2ptMSbarInt[calQ1, calQ5, plus] = 0
 
GF2ptMSbarInt[calQ2, calQ1, minus] = 0
 
GF2ptMSbarInt[calQ2, calQ1, plus] = 0
 
GF2ptMSbarInt[calQ2, calQ2, minus] = (-7*(1 + 14*Cf*gsqoverpisq16)*Nc^2*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] + delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] - 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(32*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ2, calQ2, plus] = (-7*(1 + 14*Cf*gsqoverpisq16)*Nc^2*
      (delf[f[1], fp[4]]*delf[f[2], fp[3]] - delf[f[1], fp[3]]*
        delf[f[2], fp[4]])*(delf[f[3], fp[2]]*delf[f[4], fp[1]] + 
       delf[f[3], fp[1]]*delf[f[4], fp[2]]))/(32*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ2, calQ3, minus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ2, calQ3, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ2, calQ4, minus] = 0
 
GF2ptMSbarInt[calQ2, calQ4, plus] = 0
 
GF2ptMSbarInt[calQ2, calQ5, minus] = 0
 
GF2ptMSbarInt[calQ2, calQ5, plus] = 0
 
GF2ptMSbarInt[calQ3, calQ1, minus] = 0
 
GF2ptMSbarInt[calQ3, calQ1, plus] = 0
 
GF2ptMSbarInt[calQ3, calQ2, minus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ3, calQ2, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35 + Cf*(391 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (320*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ3, calQ3, minus] = 
    -1/640*(Nc^2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(35 + Cf*(251 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ3, calQ3, plus] = 
    -1/640*(Nc^2*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(35 + Cf*(251 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ3, calQ4, minus] = 0
 
GF2ptMSbarInt[calQ3, calQ4, plus] = 0
 
GF2ptMSbarInt[calQ3, calQ5, minus] = 0
 
GF2ptMSbarInt[calQ3, calQ5, plus] = 0
 
GF2ptMSbarInt[calQ4, calQ1, minus] = 0
 
GF2ptMSbarInt[calQ4, calQ1, plus] = 0
 
GF2ptMSbarInt[calQ4, calQ2, minus] = 0
 
GF2ptMSbarInt[calQ4, calQ2, plus] = 0
 
GF2ptMSbarInt[calQ4, calQ3, minus] = 0
 
GF2ptMSbarInt[calQ4, calQ3, plus] = 0
 
GF2ptMSbarInt[calQ4, calQ4, minus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(35 + 70*Nc + Cf*gsqoverpisq16*
        (-87 + 502*Nc + 840*EulerGamma*(3 + 2*Nc)) + 420*Cf*gsqoverpisq16*
        (3 + 2*Nc)*Log[mubarsq*tsq]))/(1280*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ4, calQ4, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(-35 + 70*Nc + Cf*gsqoverpisq16*
        (87 + 502*Nc + 840*EulerGamma*(-3 + 2*Nc)) + 420*Cf*gsqoverpisq16*
        (-3 + 2*Nc)*Log[mubarsq*tsq]))/(1280*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ4, calQ5, minus] = 
    -1/640*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ4, calQ5, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (640*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ5, calQ1, minus] = 0
 
GF2ptMSbarInt[calQ5, calQ1, plus] = 0
 
GF2ptMSbarInt[calQ5, calQ2, minus] = 0
 
GF2ptMSbarInt[calQ5, calQ2, plus] = 0
 
GF2ptMSbarInt[calQ5, calQ3, minus] = 0
 
GF2ptMSbarInt[calQ5, calQ3, plus] = 0
 
GF2ptMSbarInt[calQ5, calQ4, minus] = 
    -1/640*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
         gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
      (Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ5, calQ4, plus] = 
    (Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
       delf[f[1], fp[3]]*delf[f[2], fp[4]])*
      (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
        delf[f[4], fp[2]])*(105 + Cf*(1651 + 840*EulerGamma)*
        gsqoverpisq16 + 420*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/
     (640*Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ5, calQ5, minus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] - 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] - delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(105 - 210*Nc + Cf*gsqoverpisq16*
         (3563 - 3418*Nc + 840*EulerGamma*(-7 + 2*Nc)) + 
        420*Cf*gsqoverpisq16*(-7 + 2*Nc)*Log[mubarsq*tsq]))/(Pi^6*tsq^(9/2))
 
GF2ptMSbarInt[calQ5, calQ5, plus] = 
    -1/320*(Nc*(delf[f[1], fp[4]]*delf[f[2], fp[3]] + 
        delf[f[1], fp[3]]*delf[f[2], fp[4]])*
       (delf[f[3], fp[2]]*delf[f[4], fp[1]] + delf[f[3], fp[1]]*
         delf[f[4], fp[2]])*(-105*(1 + 2*Nc) + Cf*gsqoverpisq16*
         (-3563 - 3418*Nc + 840*EulerGamma*(7 + 2*Nc)) + 
        420*Cf*gsqoverpisq16*(7 + 2*Nc)*Log[mubarsq*tsq]))/(Pi^6*tsq^(9/2))

GF3ptMSbarInt[S, Q1, S, minus] = 
    -1/2*(Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q1, S, plus] = (Cf*gsqoverpisq16*Nc*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(2*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q2, S, minus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + 24*Cf*EulerGamma*gsqoverpisq16 + 
       12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(16*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q2, S, plus] = 
    -1/16*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 24*Cf*EulerGamma*gsqoverpisq16 + 
        12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q3, S, minus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 2*Cf*gsqoverpisq16*
        (-4 - Nc + 12*EulerGamma*Nc) + 12*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q3, S, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(Nc + 2*Cf*gsqoverpisq16*
        (4 - Nc + 12*EulerGamma*Nc) + 12*Cf*gsqoverpisq16*Nc*
        Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q4, S, minus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + 2*Nc + Cf*gsqoverpisq16*
        (3 - 4*Nc + 48*EulerGamma*(1 + Nc) - 24*Log[2]) + 
       24*Cf*gsqoverpisq16*(1 + Nc)*Log[mubarsq*tsq]))/(64*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q4, S, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-1 + 2*Nc + Cf*gsqoverpisq16*
        (-3 + 48*EulerGamma*(-1 + Nc) - 4*Nc + 24*Log[2]) + 
       24*Cf*gsqoverpisq16*(-1 + Nc)*Log[mubarsq*tsq]))/(64*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q5, S, minus] = 
    (-3*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + Cf*gsqoverpisq16*(-1 + 16*EulerGamma + 
         8*Log[2]) + 8*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, Q5, S, plus] = 
    (3*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + Cf*gsqoverpisq16*(-1 + 16*EulerGamma + 
         8*Log[2]) + 8*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)

GF3ptMSbarInt[P, Q1, P, minus] = 0
 
GF3ptMSbarInt[P, Q1, P, plus] = 0
 
GF3ptMSbarInt[P, Q2, P, minus] = 
    -1/16*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 8*Cf*(4 + 3*EulerGamma)*gsqoverpisq16 + 
        12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[P, Q2, P, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + 8*Cf*(4 + 3*EulerGamma)*gsqoverpisq16 + 
       12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(16*Pi^4*tsq^3)
 
GF3ptMSbarInt[P, Q3, P, minus] = 
    -1/32*(Nc^2*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 6*Cf*(5 + 4*EulerGamma)*gsqoverpisq16 + 
        12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[P, Q3, P, plus] = 
    -1/32*(Nc^2*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 6*Cf*(5 + 4*EulerGamma)*gsqoverpisq16 + 
        12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[P, Q4, P, minus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + 2*Nc + Cf*gsqoverpisq16*
        (35 + 60*Nc + 48*EulerGamma*(1 + Nc) - 24*Log[2]) + 
       24*Cf*gsqoverpisq16*(1 + Nc)*Log[mubarsq*tsq]))/(64*Pi^4*tsq^3)
 
GF3ptMSbarInt[P, Q4, P, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-1 + 2*Nc + Cf*gsqoverpisq16*
        (-35 + 48*EulerGamma*(-1 + Nc) + 60*Nc + 24*Log[2]) + 
       24*Cf*gsqoverpisq16*(-1 + Nc)*Log[mubarsq*tsq]))/(64*Pi^4*tsq^3)
 
GF3ptMSbarInt[P, Q5, P, minus] = 
    (-3*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + Cf*gsqoverpisq16*(31 + 16*EulerGamma + 
         8*Log[2]) + 8*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)
 
GF3ptMSbarInt[P, Q5, P, plus] = 
    (3*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + Cf*gsqoverpisq16*(31 + 16*EulerGamma + 
         8*Log[2]) + 8*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)

GF3ptMSbarInt[V, Q1, V, minus] = 
    ((-1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(8*Nc + gsqoverpisq16*(1 + Nc)*
        (-41 + 48*EulerGamma + 24*Nc - 48*Log[2]) + 24*gsqoverpisq16*(1 + Nc)*
        Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q1, V, plus] = 
    ((1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(8*Nc + gsqoverpisq16*(-1 + Nc)*
        (41 - 48*EulerGamma + 24*Nc + 48*Log[2]) - 24*gsqoverpisq16*(-1 + Nc)*
        Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q2, V, minus] = ((1 + 6*Cf*gsqoverpisq16)*Nc^2*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(72*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q2, V, plus] = ((1 + 6*Cf*gsqoverpisq16)*Nc^2*
      (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
        delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
        delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(72*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q3, V, minus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(4 + Cf*gsqoverpisq16*(23 + 48*EulerGamma - 
         48*Log[2]) + 24*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q3, V, plus] = 
    -1/576*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(4 + Cf*gsqoverpisq16*(23 + 48*EulerGamma - 
          48*Log[2]) + 24*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q4, V, minus] = 
    -1/12*(Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], 
          fpp[2]] - delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q4, V, plus] = 
    (Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(12*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q5, V, minus] = 
    -1/6*(Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[V, Q5, V, plus] = 
    (Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(6*Pi^4*tsq^3)

GF3ptMSbarInt[A, Q1, A, minus] = 
    ((-1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(8*Nc + gsqoverpisq16*(1 + Nc)*
        (-105 + 48*EulerGamma + 88*Nc - 48*Log[2]) + 
       24*gsqoverpisq16*(1 + Nc)*Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q1, A, plus] = 
    ((1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(8*Nc + gsqoverpisq16*(-1 + Nc)*
        (105 - 48*EulerGamma + 88*Nc + 48*Log[2]) - 24*gsqoverpisq16*
        (-1 + Nc)*Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q2, A, minus] = 
    -1/72*(Nc*(Nc + 2*Cf*gsqoverpisq16*(-4 + 11*Nc))*
       (delf[fp[2], f[2]]*delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q2, A, plus] = 
    -1/72*(Nc*(Nc + 2*Cf*gsqoverpisq16*(4 + 11*Nc))*
       (delf[fp[2], f[2]]*delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q3, A, minus] = 
    -1/576*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(4 + 3*Cf*gsqoverpisq16*
         (29 + 16*EulerGamma - 16*Log[2]) + 24*Cf*gsqoverpisq16*
         Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q3, A, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(4 + 3*Cf*gsqoverpisq16*
        (29 + 16*EulerGamma - 16*Log[2]) + 24*Cf*gsqoverpisq16*
        Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q4, A, minus] = 
    (Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(36*Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q4, A, plus] = 
    -1/36*(Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], 
          fpp[2]] + delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q5, A, minus] = 
    -1/6*(Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[A, Q5, A, plus] = 
    (Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(6*Pi^4*tsq^3)

GF3ptMSbarInt[T, Q1, T, minus] = 
    -1/36*(Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], 
          fpp[2]] - delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q1, T, plus] = 
    (Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(36*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q2, T, minus] = 
    (-11*Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(192*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q2, T, plus] = 
    (11*Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(192*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q3, T, minus] = 
    (Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(72*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q3, T, plus] = 
    -1/72*(Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], 
          fpp[2]] + delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q4, T, minus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-1 + Cf*gsqoverpisq16*(-15 + 8*Log[2])))/
     (576*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q4, T, plus] = 
    -1/576*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-1 + Cf*gsqoverpisq16*(-15 + 8*Log[2])))/
      (Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q5, T, minus] = 
    -1/864*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(3 - 6*Nc + Cf*gsqoverpisq16*
         (89 + 48*EulerGamma*(-2 + Nc) - 100*Nc + 72*Log[2]) + 
        24*Cf*gsqoverpisq16*(-2 + Nc)*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[T, Q5, T, plus] = 
    -1/864*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-3 - 6*Nc + Cf*gsqoverpisq16*
         (-89 - 100*Nc + 48*EulerGamma*(2 + Nc) - 72*Log[2]) + 
        24*Cf*gsqoverpisq16*(2 + Nc)*Log[mubarsq*tsq]))/(Pi^4*tsq^3)

GF3ptMSbarInt[S, calQ1, P, minus] = 0
 
GF3ptMSbarInt[S, calQ1, P, plus] = 0
 
GF3ptMSbarInt[S, calQ2, P, minus] = 
    -1/16*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 8*Cf*(2 + 3*EulerGamma)*gsqoverpisq16 + 
        12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[S, calQ2, P, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + 8*Cf*(2 + 3*EulerGamma)*gsqoverpisq16 + 
       12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(16*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, calQ3, P, minus] = 
    -1/32*(Nc^2*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 2*Cf*(7 + 12*EulerGamma)*
         gsqoverpisq16 + 12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[S, calQ3, P, plus] = 
    -1/32*(Nc^2*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 2*Cf*(7 + 12*EulerGamma)*
         gsqoverpisq16 + 12*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[S, calQ4, P, minus] = 
    -1/64*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(1 + 2*Nc + Cf*gsqoverpisq16*
         (19 + 28*Nc + 48*EulerGamma*(1 + Nc) - 24*Log[2]) + 
        24*Cf*gsqoverpisq16*(1 + Nc)*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[S, calQ4, P, plus] = 
    -1/64*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-1 + 2*Nc + Cf*gsqoverpisq16*
         (-19 + 48*EulerGamma*(-1 + Nc) + 28*Nc + 24*Log[2]) + 
        24*Cf*gsqoverpisq16*(-1 + Nc)*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[S, calQ5, P, minus] = 
    (3*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + Cf*gsqoverpisq16*(15 + 16*EulerGamma + 
         8*Log[2]) + 8*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)
 
GF3ptMSbarInt[S, calQ5, P, plus] = 
    (-3*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(1 + Cf*gsqoverpisq16*(15 + 16*EulerGamma + 
         8*Log[2]) + 8*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(32*Pi^4*tsq^3)

GF3ptMSbarInt[V, calQ1, A, minus] = 
    ((-1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(8*Nc + gsqoverpisq16*(1 + Nc)*
        (-73 + 48*EulerGamma + 56*Nc - 48*Log[2]) + 24*gsqoverpisq16*(1 + Nc)*
        Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, calQ1, A, plus] = 
    ((1 + Nc)*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(8*Nc + gsqoverpisq16*(-1 + Nc)*
        (73 - 48*EulerGamma + 56*Nc + 48*Log[2]) - 24*gsqoverpisq16*(-1 + Nc)*
        Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, calQ2, A, minus] = 
    -1/72*((1 + 14*Cf*gsqoverpisq16)*Nc^2*(delf[fp[2], f[2]]*
         delf[f[1], fpp[2]] + delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[V, calQ2, A, plus] = 
    -1/72*((1 + 14*Cf*gsqoverpisq16)*Nc^2*(delf[fp[2], f[2]]*
         delf[f[1], fpp[2]] - delf[fp[2], f[1]]*
         delf[f[2], fpp[2]])*(delf[fp[1], f[4]]*
         delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
         delf[f[4], fpp[1]]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[V, calQ3, A, minus] = 
    -1/576*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(4 + Cf*gsqoverpisq16*(55 + 48*EulerGamma - 
          48*Log[2]) + 24*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(Pi^4*tsq^3)
 
GF3ptMSbarInt[V, calQ3, A, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(4 + Cf*gsqoverpisq16*(55 + 48*EulerGamma - 
         48*Log[2]) + 24*Cf*gsqoverpisq16*Log[mubarsq*tsq]))/(576*Pi^4*tsq^3)
 
GF3ptMSbarInt[V, calQ4, A, minus] = 0
 
GF3ptMSbarInt[V, calQ4, A, plus] = 0
 
GF3ptMSbarInt[V, calQ5, A, minus] = 0
 
GF3ptMSbarInt[V, calQ5, A, plus] = 0

GF3ptMSbarInt[T, calQ1, Tp, minus] = 0
 
GF3ptMSbarInt[T, calQ1, Tp, plus] = 0
 
GF3ptMSbarInt[T, calQ2, Tp, minus] = 
    (11*Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(192*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, calQ2, Tp, plus] = 
    (-11*Cf*gsqoverpisq16*Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]]))/(192*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, calQ3, Tp, minus] = 0
 
GF3ptMSbarInt[T, calQ3, Tp, plus] = 0
 
GF3ptMSbarInt[T, calQ4, Tp, minus] = 
    -1/576*(Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
        delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
       (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
         delf[f[4], fpp[1]])*(-1 + Cf*gsqoverpisq16*(-15 + 8*Log[2])))/
      (Pi^4*tsq^3)
 
GF3ptMSbarInt[T, calQ4, Tp, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-1 + Cf*gsqoverpisq16*(-15 + 8*Log[2])))/
     (576*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, calQ5, Tp, minus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] - 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] - delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(3 - 6*Nc + Cf*gsqoverpisq16*
        (89 + 48*EulerGamma*(-2 + Nc) - 100*Nc + 72*Log[2]) + 
       24*Cf*gsqoverpisq16*(-2 + Nc)*Log[mubarsq*tsq]))/(864*Pi^4*tsq^3)
 
GF3ptMSbarInt[T, calQ5, Tp, plus] = 
    (Nc*(delf[fp[2], f[2]]*delf[f[1], fpp[2]] + 
       delf[fp[2], f[1]]*delf[f[2], fpp[2]])*
      (delf[fp[1], f[4]]*delf[f[3], fpp[1]] + delf[fp[1], f[3]]*
        delf[f[4], fpp[1]])*(-3 - 6*Nc + Cf*gsqoverpisq16*
        (-89 - 100*Nc + 48*EulerGamma*(2 + Nc) - 72*Log[2]) + 
       24*Cf*gsqoverpisq16*(2 + Nc)*Log[mubarsq*tsq]))/(864*Pi^4*tsq^3)

